DATA ANALYST PORTFOLIO WEBSITE

HOW TO OPEN
1. Extract this ZIP completely.
2. Open the Data-Analyst-Portfolio folder in VS Code or Antigravity.
3. Open index.html.
4. Recommended: install the Live Server extension in VS Code, right-click index.html, and choose Open with Live Server.
5. If Open with Live Server is missing, open Extensions (Ctrl+Shift+X), search for Live Server, install it, and reload VS Code.

Keep the css, js, fonts, and images folders next to index.html. Do not move index.html by itself.
Some external fonts may require an internet connection.
